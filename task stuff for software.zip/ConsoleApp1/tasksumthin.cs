﻿using System.Collections.Generic;

public class TaskRepository
{
    private readonly List<Task> _taskList = new List<Task>();

    public void AddTask(Task task)
    {
        _taskList.Add(task);
    }

    public Task GetTaskById(int id)
    {
        return _taskList.Find(t => t.Id == id);
    }

    public List<Task> GetAllTasks()
    {
        return _taskList;
    }

    public void FinishTask(int id)
    {
        var task = GetTaskById(id);
        if (task != null)
        {
            task.Status = "completed";
        }
    }
}
