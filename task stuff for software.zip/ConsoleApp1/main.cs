﻿public class Program
{
    public static void Main()
    {
        TaskManager taskManager = new TaskManager();
        taskManager.ShowTaskMenu();
    }
}
