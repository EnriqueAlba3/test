﻿using System;

public class TaskManager
{
    private readonly TaskRepository _taskRepository = new TaskRepository();

    public void ShowTaskMenu()
    {
        Console.WriteLine("Task Menu");
        Console.WriteLine("1. Add Task");
        Console.WriteLine("2. Finish Task");
        Console.WriteLine("3. Display Tasks");
        Console.WriteLine("4. Quit");

        var choice = Console.ReadLine();
        HandleMenuChoice(choice);
    }

    private void HandleMenuChoice(string choice)
    {
        switch (choice)
        {
            case "1":
                AddTask();
                break;
            case "2":
                FinishTask();
                break;
            case "3":
                DisplayTasks();
                break;
            case "4":
                Console.WriteLine("Exiting...");
                break;
            default:
                Console.WriteLine("Invalid selection, please choose again.");
                ShowTaskMenu();
                break;
        }
    }

    private void AddTask()
    {
        Console.WriteLine("Enter Task Details:");
        var details = Console.ReadLine();
        var task = new Task(details);
        _taskRepository.AddTask(task);
        Console.WriteLine("Task added successfully.");
        ShowTaskMenu();
    }

    private void FinishTask()
    {
        Console.WriteLine("Enter Task ID to mark as completed:");
        if (int.TryParse(Console.ReadLine(), out var id))
        {
            _taskRepository.FinishTask(id);
            Console.WriteLine("Task marked as completed.");
        }
        else
        {
            Console.WriteLine("Invalid ID.");
        }
        ShowTaskMenu();
    }

    private void DisplayTasks()
    {
        var tasks = _taskRepository.GetAllTasks();
        foreach (var task in tasks)
        {
            Console.WriteLine($"ID: {task.Id}, Details: {task.Details}, Status: {task.Status}");
        }
        ShowTaskMenu();
    }
}
