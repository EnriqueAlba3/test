﻿public class Task
{
    public int Id { get; set; }
    public string Details { get; set; }
    public string Status { get; set; } = "pending"; // Default status

    public Task(string details)
    {
        Details = details;
    }
}